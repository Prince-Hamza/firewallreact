const fs = require('fs')
const glob = require('glob')
let path="./icons/"
var files = fs.readdirSync(path).filter(file => fs.lstatSync(path + file).isFile())

console.log(files)